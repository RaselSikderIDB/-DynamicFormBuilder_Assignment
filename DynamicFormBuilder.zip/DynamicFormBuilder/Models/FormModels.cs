﻿using System;
using System.Collections.Generic;

namespace DynamicFormBuilder.Models
{
    public class FormModel
    {
        public int FormId { get; set; }
        public string Title { get; set; }
        public DateTime CreatedDate { get; set; }
        public List<FormFieldModel> Fields { get; set; } = new();
    }

    public class FormFieldModel
    {
        public int FieldId { get; set; }
        public string Label { get; set; }
        public bool IsRequired { get; set; }
        public string SelectedOption { get; set; }
        public int SortOrder { get; set; }
    }

    public class SaveFormDto
    {
        public string Title { get; set; }
        public List<SaveFieldDto> Fields { get; set; } = new();
    }

    public class SaveFieldDto
    {
        public string Label { get; set; }
        public bool IsRequired { get; set; }
        public string SelectedOption { get; set; }
    }
}
