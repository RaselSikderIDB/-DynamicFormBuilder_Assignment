﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using DynamicFormBuilder.Models;
using Microsoft.Extensions.Configuration;

namespace DynamicFormBuilder.Controllers
{
    public class FormBuilderController : Controller
    {
        private readonly string _conn;
        public FormBuilderController(IConfiguration cfg) => _conn = cfg.GetConnectionString("DefaultConnection");

        public IActionResult Index() => View();

        [HttpPost]
        public async Task<IActionResult> Save([FromBody] SaveFormDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.Title))
                return BadRequest(new { success = false, message = "Form title required" });

            try
            {
                using var conn = new SqlConnection(_conn);
                await conn.OpenAsync();
                using var tran = conn.BeginTransaction();

                int newFormId;
                using (var cmd = new SqlCommand("dbo.usp_InsertForm", conn, tran) { CommandType = CommandType.StoredProcedure })
                {
                    cmd.Parameters.AddWithValue("@Title", dto.Title);
                    var outp = new SqlParameter("@NewFormId", SqlDbType.Int) { Direction = ParameterDirection.Output };
                    cmd.Parameters.Add(outp);
                    await cmd.ExecuteNonQueryAsync();
                    newFormId = (int)outp.Value;
                }

                int sort = 0;
                foreach (var f in dto.Fields ?? new List<SaveFieldDto>())
                {
                    using var cmdF = new SqlCommand("dbo.usp_InsertFormField", conn, tran) { CommandType = CommandType.StoredProcedure };
                    cmdF.Parameters.AddWithValue("@FormId", newFormId);
                    cmdF.Parameters.AddWithValue("@Label", (object)f.Label ?? DBNull.Value);
                    cmdF.Parameters.AddWithValue("@IsRequired", f.IsRequired);
                    cmdF.Parameters.AddWithValue("@SelectedOption", (object)f.SelectedOption ?? DBNull.Value);
                    cmdF.Parameters.AddWithValue("@SortOrder", sort++);
                    await cmdF.ExecuteNonQueryAsync();
                }

                tran.Commit();
                return Ok(new { success = true, formId = newFormId });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        public IActionResult History() => View();

        //[HttpPost]
        //public async Task<IActionResult> GetFormsDataTable()
        //{
        //    var draw = Request.Form["draw"].ToString();
        //    var start = int.TryParse(Request.Form["start"], out var s) ? s : 0;
        //    var length = int.TryParse(Request.Form["length"], out var l) ? l : 10;
        //    var search = Request.Form["search[value]"].ToString() ?? string.Empty;

        //    var data = new List<object>();
        //    int total = 0;

        //    try
        //    {
        //        using var conn = new SqlConnection(_conn);
        //        await conn.OpenAsync();

        //        using (var cnt = new SqlCommand("SELECT COUNT(*) FROM dbo.Forms WHERE (@s = '' OR Title LIKE '%' + @s + '%')", conn))
        //        {
        //            cnt.Parameters.AddWithValue("@s", search);
        //            total = (int)await cnt.ExecuteScalarAsync();
        //        }

        //        using (var cmd = new SqlCommand("dbo.usp_GetFormsPaged", conn) { CommandType = CommandType.StoredProcedure })
        //        {
        //            cmd.Parameters.AddWithValue("@Start", start);
        //            cmd.Parameters.AddWithValue("@Length", length);
        //            cmd.Parameters.AddWithValue("@Search", search);
        //            using var rdr = await cmd.ExecuteReaderAsync();
        //            while (await rdr.ReadAsync())
        //            {
        //                data.Add(new
        //                {
        //                    FormId = rdr.GetInt32(0),
        //                    Title = rdr.GetString(1),
        //                    CreatedDate = rdr.GetDateTime(2).ToString("yyyy-MM-dd HH:mm")
        //                });
        //            }
        //        }

        //        return Json(new { draw = draw, recordsTotal = total, recordsFiltered = total, data = data });
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, new { success = false, message = ex.Message });
        //    }
        //}

        //[HttpPost]
        //public IActionResult GetFormsDataTable()
        //{
        //    string draw = Request.Form["draw"].FirstOrDefault();
        //    int start = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
        //    int length = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "10");
        //    string search = Request.Form["search[value]"].FirstOrDefault();

        //    List<object> data = new List<object>();
        //    int total = 0;

        //    using (SqlConnection conn = new SqlConnection(_conn))
        //    using (SqlCommand cmd = new SqlCommand("usp_GetFormsPaged", conn))
        //    {
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@Start", start);
        //        cmd.Parameters.AddWithValue("@Length", length);
        //        cmd.Parameters.AddWithValue("@Search", search ?? string.Empty);

        //        conn.Open();
        //        using (SqlDataReader rdr = cmd.ExecuteReader())
        //        {
        //            while (rdr.Read())
        //            {
        //                data.Add(new
        //                {
        //                    //FormId = rdr.GetInt32(0),
        //                    Title = rdr.GetString(1),
        //                    CreatedDate = rdr.GetDateTime(2).ToString("yyyy-MM-dd HH:mm")
        //                });
        //            }
        //        }

        //        // Count total rows
        //        SqlCommand countCmd = new SqlCommand("SELECT COUNT(*) FROM dbo.Forms", conn);
        //        total = (int)countCmd.ExecuteScalar();
        //    }

        //    return Json(new { draw, recordsTotal = total, recordsFiltered = total, data });
        //}


        [HttpPost]
        public IActionResult GetFormsDataTable()
        {
            string draw = Request.Form["draw"].FirstOrDefault();
            int start = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            int length = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "10");
            string search = Request.Form["search[value]"].FirstOrDefault();

            List<object> data = new List<object>();
            int total = 0;

            using (SqlConnection conn = new SqlConnection(_conn))
            using (SqlCommand cmd = new SqlCommand("usp_GetFormsPaged", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Start", start);
                cmd.Parameters.AddWithValue("@Length", length);
                cmd.Parameters.AddWithValue("@Search", search ?? string.Empty);

                conn.Open();
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        data.Add(new
                        {
                            FormId = rdr.GetInt32(0),
                            Title = rdr["Title"].ToString(),
                            CreatedDate = Convert.ToDateTime(rdr["CreatedDate"]).ToString("yyyy-MM-dd HH:mm")
                        });
                    }
                }

                // Count total rows
                SqlCommand countCmd = new SqlCommand("SELECT COUNT(*) FROM dbo.Forms", conn);
                total = (int)countCmd.ExecuteScalar();
            }

            return Json(new { draw, recordsTotal = total, recordsFiltered = total, data });
        }
        public async Task<IActionResult> Preview(int id)
        {
            if (id <= 0)
                return BadRequest("Invalid Form ID.");

            var model = new FormModel();

            try
            {
                using var conn = new SqlConnection(_conn);
                await conn.OpenAsync();

                using var cmd = new SqlCommand("dbo.usp_GetFormById", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@FormId", id);

                using var rdr = await cmd.ExecuteReaderAsync();

                if (await rdr.ReadAsync())
                {
                    model.FormId = rdr.GetInt32(0);
                    model.Title = rdr.GetString(1);
                    model.CreatedDate = rdr.GetDateTime(2);
                }

                if (await rdr.NextResultAsync())
                {
                    while (await rdr.ReadAsync())
                    {
                        model.Fields.Add(new FormFieldModel
                        {
                            FieldId = rdr.GetInt32(0),
                            Label = rdr.IsDBNull(1) ? "" : rdr.GetString(1),
                            IsRequired = rdr.GetBoolean(2),
                            SelectedOption = rdr.IsDBNull(3) ? null : rdr.GetString(3),
                            SortOrder = rdr.GetInt32(4)
                        });
                    }
                }

                return View(model);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

    }
}
